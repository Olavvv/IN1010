public class Hovedprogram {
    public static void main(String[] args) throws Exception {
        Legesystem legesystem = new Legesystem();
        //legesystem.lesFraFil("eksempelfil.txt");

        legesystem.meny();
    }
}
