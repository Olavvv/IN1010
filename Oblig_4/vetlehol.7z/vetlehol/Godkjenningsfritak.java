interface Godkjenningsfritak {
    String hentKontrollkode();
}
